drop database eventodb;

create database eventodb;

use eventodb;

select * from casaDeEventos;

select * from evento;

CREATE TABLE casaDeEventos (
cnpj varchar(14) PRIMARY KEY,
nome varchar(50),
eventos varchar(50),
endereco varchar(50)
);

CREATE TABLE evento (
idEvento int PRIMARY KEY auto_increment,
nome varchar(50),
cnpj varchar(14),
dataInicio date,
dataFim date,
ingressos varchar(30),
qtdeMaxIngressos int,
cabecalho varchar(50),
statusEvento varchar(20),
FOREIGN KEY(cnpj) REFERENCES casaDeEventos (cnpj)
);

CREATE TABLE pontoDeVenda (
idPontoDeVenda int PRIMARY KEY auto_increment,
nome varchar(50)
);

CREATE TABLE ingresso (
codigo varchar(14) PRIMARY KEY,
valor double,
evento varchar(20),
Atributo_2 varchar(20),
lote varchar(5),
categoria varchar(50),
idEvento int,
FOREIGN KEY(idEvento) REFERENCES evento (idEvento)
);

CREATE TABLE autorizacao (
dataAutorizacao date,
evento varchar(20),
pdv varchar(20),
idPontoDeVenda int,
idEvento int,
FOREIGN KEY(idPontoDeVenda) REFERENCES pontoDeVenda (idPontoDeVenda),
FOREIGN KEY(idEvento) REFERENCES evento (idEvento)
);

CREATE TABLE vendaIngresso (
ingresso varchar(20),
dataDaVenda date,
pdv varchar(20),
idPontoDeVenda int,
codigo varchar(14) not null,
FOREIGN KEY(idPontoDeVenda) REFERENCES pontoDeVenda (idPontoDeVenda)
);