package br.acessumimperium.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VendaIngresso {

	//ATRIBUTOS DA CLASSE ...
	private Date dataDaVenda;
	private int idPontoDeVenda; 
	private int codigo;
	
	//MÉTODOS GETTERS AND SETTERS ...
	public Date getDataDaVenda() {
		return dataDaVenda;
	}
	public void setDataDaVenda(String dataDaVenda) {
		SimpleDateFormat df = new SimpleDateFormat();
		Date data = null;
		
		try {
			data = df.parse(dataDaVenda);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.dataDaVenda = data;
	}//FIM FORMATAÇÃO dataDaVenda ...
	public int getIdPontoDeVenda() {
		return idPontoDeVenda;
	}
	public void setIdPontoDeVenda(int idPontoDeVenda) {
		this.idPontoDeVenda = idPontoDeVenda;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}	
}
