package br.acessumimperium.modelo;

public class Ingresso {

	//ATRIBUTOS DA CLASSE ...
	private String codigo;
	private Double valor;
	private String categoria;
	private String lote;
	private Evento idEvento; //CHAVE ESTRANGEIRA ...
	
	//MÉTODOS GETTERS AND SETTERS ...
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public Double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getLote() {
		return lote;
	}
	public void setLote(String lote) {
		this.lote = lote;
	}
	public Evento getIdEvento() {
		return idEvento;
	}
	public void setIdEvento(Evento idEvento) {
		this.idEvento = idEvento;
	}	
}
