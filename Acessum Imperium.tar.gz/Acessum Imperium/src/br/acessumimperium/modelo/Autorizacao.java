package br.acessumimperium.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Autorizacao {

	private Date dataAutorizacao;
	private String evento;
	private String pdv;
	private PontoDeVenda idPontoDeVenda; //CHAVE ESTRANGEIRA ...
	private Evento idEvento; //CHAVE ESTRANGEIRA ...
	
	//MÉTODOS GETTERS AND SETTERS ...
	public Date getDataAutorizacao() {
		return dataAutorizacao;
	}
	public void setDataAutorizacao(String dataAutorizacao) {
		SimpleDateFormat df = new SimpleDateFormat("dd,MM,yyyy");
		Date data = null;
		
		try {
			data = df.parse(dataAutorizacao);			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.dataAutorizacao = data;
	}//FIM FORMATAÇÃO dataAutorizacao ...
	public String getEvento() {
		return evento;
	}
	public void setEvento(String evento) {
		this.evento = evento;
	}
	public String getPdv() {
		return pdv;
	}
	public void setPdv(String pdv) {
		this.pdv = pdv;
	}
	public PontoDeVenda getIdPontoDeVenda() {
		return idPontoDeVenda;
	}
	public void setIdPontoDeVenda(PontoDeVenda idPontoDeVenda) {
		this.idPontoDeVenda = idPontoDeVenda;
	}
	public Evento getIdEvento() {
		return idEvento;
	}
	public void setIdEvento(Evento idEvento) {
		this.idEvento = idEvento;
	}
	
	
	
}
