package br.acessumimperium.modelo;

public class PontoDeVenda {

	//ATRIBUTOS DA CLASSE ...
	private int idPontoDeVenda;
	private String nome;
	
	//MÉTODOS GETTERS AND SETTERS ...
	public int getIdPontoDeVenda() {
		return idPontoDeVenda;
	}
	public void setIdPontoDeVenda(int idPontoDeVenda) {
		this.idPontoDeVenda = idPontoDeVenda;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}	
}
