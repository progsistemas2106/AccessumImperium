package br.acessumimperium.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Evento {

	//ATRIBUTOS DA CLASSE ...
	private String nome;
	private CasaDeEventos casaDeEventos;
	private Date dataInicio;
    private Date dataFim;    
    private String ingressos;
    private int qtdeMaxIngressos;
    private String cabecalho;
    private String statusEvento;
    
        
    //MÉTODOS GETTERS AND SETTERS ...

	public Date getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(String dataInicio) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date data = null;
		
		try {
			data = df.parse(dataInicio);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.dataInicio = data;
	}//Fim formatação dataInicio
	public Date getDataFim() {
		return dataFim;
	}
	public void setDataFim(String dataFim) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date data = null;
		
		try {
			data = df.parse(dataFim);			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.dataFim = data;
	}//Fim formatação dataFim
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public CasaDeEventos getCasaDeEventos() {
		return casaDeEventos;
	}
	public void setCasaDeEventos(CasaDeEventos casaDeEventos) {
		this.casaDeEventos = casaDeEventos;
	}
	public String getIngressos() {
		return ingressos;
	}
	public void setIngressos(String ingressos) {
		this.ingressos = ingressos;
	}
	public int getQtdeMaxIngressos() {
		return qtdeMaxIngressos;
	}
	public void setQtdeMaxIngressos(int qtdeMaxIngressos) {
		this.qtdeMaxIngressos = qtdeMaxIngressos;
	}
	public String getCabecalho() {
		return cabecalho;
	}
	public void setCabecalho(String cabecalho) {
		this.cabecalho = cabecalho;
	}
	public String getStatusEvento() {
		return statusEvento;
	}
	public void setStatusEvento(String statusEvento) {
		this.statusEvento = statusEvento;
	}
	
		    
}
