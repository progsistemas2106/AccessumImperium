package br.acessumimperium.modelo;

public class CasaDeEventos {
	
	//ATRIBUTOS DA CLASSE ...
	private String cnpj;
	private String nome;
	private String evento;
	private String endereco;
	
	//MÉTODOS GETTERS AND SETTERS ...
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEvento() {
		return evento;
	}
	public void setEvento(String evento) {
		this.evento = evento;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}	
}
