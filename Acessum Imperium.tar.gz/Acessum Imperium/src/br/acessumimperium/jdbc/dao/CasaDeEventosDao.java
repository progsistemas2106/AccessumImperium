package br.acessumimperium.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.acessumimperiu.jdbc.FabricaConexao;
import br.acessumimperium.modelo.CasaDeEventos;

public class CasaDeEventosDao {

	private Connection conexaoBD;
	
	//CONSTRUTOR ...
	public CasaDeEventosDao(){
		conexaoBD = new FabricaConexao().getConexao();
	}//FIM DO CONSTRUTOR  ....
	
	public void cadastraCasaDeEventos(CasaDeEventos casaDeEventos){
		
		String comandoSQL = "insert into casaDeEventos(cnpj, nome, eventos, endereco)"
				               +"values(?,?,?,?)";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, casaDeEventos.getCnpj());
			stmt.setString(2, casaDeEventos.getNome());
			stmt.setString(3, casaDeEventos.getEvento());
			stmt.setString(4, casaDeEventos.getEndereco());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados cadastrados com sucesso .... :");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Não foi possível inserir os dados ... :(" +e.getMessage());
		}
	}
}
