package br.acessumimperium.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.acessumimperiu.jdbc.FabricaConexao;
import br.acessumimperium.modelo.Evento;

public class EventoDao {

	private Connection conexaoBD;
	
	//CONSTRUTOR
	public EventoDao(){
		conexaoBD = new FabricaConexao().getConexao();
	}//FIM CONSTRUTOR
	
	public void cadastraEvento(Evento evento){
		String comandoSQL = "insert into evento (nome, cnpj, dataInicio, dataFim, ingressos, qtdeMaxIngressos, cabecalho, statusEvento)"
							+"values(?,?,?,?,?,?,?,?)";	
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, evento.getNome());
			stmt.setString(2, evento.getCasaDeEventos().getCnpj());
			java.sql.Date dataInicioSQL = new java.sql.Date(evento.getDataInicio().getTime());
			java.sql.Date dataFimSQL = new java.sql.Date(evento.getDataFim().getTime());
			stmt.setDate(3, dataInicioSQL);
			stmt.setDate(4, dataFimSQL);
			stmt.setString(5, evento.getIngressos());
			stmt.setInt(6, evento.getQtdeMaxIngressos());			
			stmt.setString(7, evento.getCabecalho());	
			stmt.setString(8, evento.getStatusEvento());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados do evento cadastrados com sucesso !!! :)");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar evento no banco de dados !!! :(" +e.getMessage());
		}	
	}//FIM DO MÉTODO cadastraEvento
	
	/*public List<Evento> buscaTodosEventos(){
		
		String comandoSQL = "SELECT * FROM evento";
		try {
			List<Evento> eventoLista = new ArrayList<Evento>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Evento evento = new Evento();
				evento.setIdEvento(rs.getInt("idEvento"));
				evento.setNome(rs.getString("nome"));		
			}
			rs.close();
			stmt.close();
			return eventoLista;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao buscar dados !!! :(" +e.getMessage());
			return Collections.emptyList();
		}
	}*/
}
