package br.acessumimperium.jdbc.dao;

public class PontoDeVendaDao {

}
