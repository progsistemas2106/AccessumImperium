package br.acessumimperium.jdbc.dao;

public class IngressoDao {

}
