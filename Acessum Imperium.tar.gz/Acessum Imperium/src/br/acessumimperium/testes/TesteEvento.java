package br.acessumimperium.testes;

import br.acessumimperium.jdbc.dao.EventoDao;
import br.acessumimperium.modelo.Evento;

public class TesteEvento {

	public static void main(String[] args) {
		
		Evento evento1 = new Evento();		
				
		EventoDao eventoDao = new EventoDao();		
		
		//TESTANDO O CADASTRA EVENTO ...
		evento1.setNome("Cacique de Ramos");
		evento1.setDataInicio("04/10/2016");
		evento1.setDataFim("11/10/2016");		
		evento1.setIngressos("sei lá ... kkk");
		evento1.setQtdeMaxIngressos(1250);
		evento1.setCabecalho("TAMBÉM NÃO SEI ...");
		evento1.setStatusEvento("Ativo");	
		
		eventoDao.cadastraEvento(evento1);	
		
	}
}
