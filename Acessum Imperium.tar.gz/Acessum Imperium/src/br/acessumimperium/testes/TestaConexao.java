package br.acessumimperium.testes;

import java.sql.Connection;

import br.acessumimperiu.jdbc.FabricaConexao;

public class TestaConexao {

	public static void main(String[] args) {
		
		Connection novaConexao = new FabricaConexao().getConexao();
	}
}
