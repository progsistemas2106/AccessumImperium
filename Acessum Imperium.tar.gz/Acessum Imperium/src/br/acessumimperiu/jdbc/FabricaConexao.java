package br.acessumimperiu.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class FabricaConexao {

	public Connection getConexao(){
		
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/eventodb?autoReconnect=false&useSSL=false", "root", "C3lso1359");
		} catch (SQLException evento) {
			JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados" +evento.getMessage());
			return null;
		}
	}
}
