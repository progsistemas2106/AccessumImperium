package br.aulasjava.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class FabricaConexao {
	
	public Connection conexao(){
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/locaauto","root","");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao conectar no banco de dados: " +e.getMessage());
			return null;
		}		
	}
}
