package br.aulasjava.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.aulasjava.jdbc.FabricaConexao;
import br.aulasjava.modelo.Cliente;
import br.aulasjava.modelo.Locacao;
import br.aulasjava.modelo.Veiculo;

public class LocacaoDao {

	private Connection conexaoBD;
	
	public LocacaoDao(){
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do m�todo construtor
	
	public void adicionaBD(Locacao locacao){
		String comandoSQL = "insert into locacao (idVeiculo, idCliente, "
				+ "dataLocacao, dataPrevisaoDevolucao) values (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setInt(1, locacao.getVeiculo().getIdVeiculo());
			stmt.setInt(2, locacao.getCliente().getIdCliente());
			java.sql.Date dataLocacaoSQL = 
					new java.sql.Date(locacao.getDataLocacao().getTime());
			java.sql.Date dataPrevisaoDevolucaoSQL = 
					new java.sql.Date(locacao.getDataPrevisaoDevolucao().getTime());
			stmt.setDate(3, dataLocacaoSQL);
			stmt.setDate(4, dataPrevisaoDevolucaoSQL);
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados de loca��o gravados com sucesso");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar loca��o no banco: "
					+e.getMessage());
		}
	}//fim do m�todo adicionaBD
	public List<Locacao> buscaTodasLocacoes(){
		String comandoSQL = "select * from locacao";
		
		try {
			List<Locacao> locacaoLista = new ArrayList<Locacao>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Locacao locacao = new Locacao();
				Cliente cliente = new Cliente();
				Veiculo veiculo = new Veiculo();
				ClienteDao clienteDao = new ClienteDao();
				VeiculoDao veiculoDao = new VeiculoDao();
				
				locacao.setIdLocacao(rs.getInt("idLocacao"));
				cliente = clienteDao.buscaPorId(rs.getInt("idCliente"));
				locacao.setCliente(cliente);
				veiculo = veiculoDao.buscaPorId(rs.getInt("idVeiculo"));
				locacao.setVeiculo(veiculo);
				locacao.setDataLocacao(rs.getDate("dataLocacao"));
				locacao.setDataPrevisaoDevolucao(rs.getDate("dataPrevisaoDevolucao"));
				locacaoLista.add(locacao);
			}
			rs.close();
			stmt.close();
			return locacaoLista;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados no banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}//Fim da classe
