package br.aulasjava.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.aulasjava.jdbc.FabricaConexao;
import br.aulasjava.modelo.Veiculo;

public class VeiculoDao {
	
	private Connection conexaoBD;
	
	public VeiculoDao() {
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do construtor
	
	public void adicionaBD(Veiculo veiculo){
		String commandoSQL = "insert into veiculo (placa, modelo, ano)"
				+ "values (?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(commandoSQL);
			stmt.setString(1, veiculo.getPlaca());
			stmt.setString(2, veiculo.getModelo());
			stmt.setInt(3, veiculo.getAno());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso.");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco: "+e.getMessage());
		}
	}//Fim do m�todo adicionaBD
	
	public List<Veiculo> buscaTodosVeiculos(){
		
		String comandoSQL = "select * from veiculo";
		try {
			List<Veiculo> veiculoLista = new ArrayList<Veiculo>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Veiculo veiculo  = new Veiculo();
				veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
				veiculo.setPlaca(rs.getString("placa"));
				veiculo.setModelo(rs.getString("modelo"));
				veiculo.setAno(rs.getInt("ano"));
				veiculoLista.add(veiculo);
			}
			rs.close();
			stmt.close();
			return veiculoLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados do Banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
		
	}//Fim do m�todo buscaTodosVeiculos
	
	public Veiculo buscaPorPlaca(String placa){
		String comandoSQL = "select * from veiculo where placa = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, placa);
			ResultSet rs = stmt.executeQuery();
			Veiculo veiculo = new Veiculo();
			if(rs.first()==true){
				veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
				veiculo.setPlaca(rs.getString("placa"));
				veiculo.setModelo(rs.getString("modelo"));
				veiculo.setAno(rs.getInt("ano"));
			}else{
				JOptionPane.showMessageDialog(null, "Veiculo n�o encontrado");
			}
			rs.close();
			stmt.close();
			return veiculo;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	public Veiculo buscaPorId(int id){
		String comandoSQL = "select * from veiculo where idVeiculo = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			Veiculo veiculo = new Veiculo();
			if(rs.first()==true){
				veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
				veiculo.setPlaca(rs.getString("placa"));
				veiculo.setModelo(rs.getString("modelo"));
				veiculo.setAno(rs.getInt("ano"));
			}else{
				JOptionPane.showMessageDialog(null, "Veiculo n�o encontrado");
			}
			rs.close();
			stmt.close();
			return veiculo;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	public boolean existeVeiculo(String placa){
		String comandoSQL = "select * from veiculo where placa = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, placa);
			ResultSet rs = stmt.executeQuery();
			if(rs.first()==true){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a verifica��o: "
					+e.getMessage());
			return false;
		}
	}
	
	public void alteraDados(Veiculo veiculo){
		String comandoSQL = "update veiculo set modelo = ?, ano = ? where placa = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, veiculo.getModelo());
			stmt.setInt(2, veiculo.getAno());
			stmt.setString(3,veiculo.getPlaca());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados atualizados");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados: "
					+e.getMessage());
		}
	}//fim alteraDados
	
	public void apagaRegistro(String placa){
		String comandoSQL = "delete from veiculo where placa = ?";
		boolean check = existeVeiculo(placa);
		if(check == true){
			try {
				PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
				stmt.setString(1, placa);
				stmt.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro apagado");
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "N�o foi poss�vel apagar o registro: "
						+e.getMessage());
			}
		}else{
			JOptionPane.showMessageDialog(null,"O veiculo n�o consta no banco");
		}
		
	}//fim apagaRegistro
	
	public void fechaBanco(){
		try {
			conexaoBD.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel fechar "
					+ "a conex�o com o banco");
		}
	}//fim fechaBanco
	
}
