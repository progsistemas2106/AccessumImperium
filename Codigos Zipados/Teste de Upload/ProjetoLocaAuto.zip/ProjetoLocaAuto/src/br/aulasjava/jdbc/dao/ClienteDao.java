package br.aulasjava.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.aulasjava.jdbc.FabricaConexao;
import br.aulasjava.modelo.Cliente;

public class ClienteDao {
	
	private Connection conexaoBD;
	
	public ClienteDao() {
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do construtor
	
	public void adicionaBD(Cliente cliente){
		String commandoSQL = "insert into cliente (nome, cnh, anoValidadeCNH)"
				+ "values (?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(commandoSQL);
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getCnh());
			stmt.setInt(3, cliente.getAnoValidadeCnh());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso.");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco: "+e.getMessage());
		}
	}//Fim do m�todo adicionaBD
	
	public List<Cliente> buscaTodosClientes(){
		
		String comandoSQL = "select * from cliente";
		try {
			List<Cliente> clienteLista = new ArrayList<Cliente>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Cliente cliente  = new Cliente();
				cliente.setIdCliente(rs.getInt("idCliente"));
				cliente.setNome(rs.getString("nome"));
				cliente.setCnh(rs.getString("cnh"));
				cliente.setAnoValidadeCnh(rs.getInt("anoValidadeCNH"));
				clienteLista.add(cliente);
			}
			rs.close();
			stmt.close();
			return clienteLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados do Banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
		
	}//Fim do m�todo buscaTodosClientes
	
	public Cliente buscaPorCnh(String cnh){
		String comandoSQL = "select * from cliente where cnh = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, cnh);
			ResultSet rs = stmt.executeQuery();
			Cliente cliente = new Cliente();
			if(rs.first()==true){
				cliente.setIdCliente(rs.getInt("idCliente"));
				cliente.setNome(rs.getString("nome"));
				cliente.setCnh(rs.getString("cnh"));
				cliente.setAnoValidadeCnh(rs.getInt("anoValidadeCNH"));
			}else{
				JOptionPane.showMessageDialog(null, "Cliente n�o encontrado");
			}
			rs.close();
			stmt.close();
			return cliente;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	public Cliente buscaPorId(int id){
		String comandoSQL = "select * from cliente where idCliente = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			Cliente cliente = new Cliente();
			if(rs.first()==true){
				cliente.setIdCliente(rs.getInt("idCliente"));
				cliente.setNome(rs.getString("nome"));
				cliente.setCnh(rs.getString("cnh"));
				cliente.setAnoValidadeCnh(rs.getInt("anoValidadeCNH"));
			}else{
				JOptionPane.showMessageDialog(null, "Cliente n�o encontrado");
			}
			rs.close();
			stmt.close();
			return cliente;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	public boolean existeCliente(String cnh){
		String comandoSQL = "select * from cliente where cnh = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, cnh);
			ResultSet rs = stmt.executeQuery();
			if(rs.first()==true){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a verifica��o: "
					+e.getMessage());
			return false;
		}
	}
	
	public void alteraDados(Cliente cliente){
		String comandoSQL = "update cliente set nome = ?, anoValidadeCNH = ? where cnh = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, cliente.getNome());
			stmt.setInt(2, cliente.getAnoValidadeCnh());
			stmt.setString(3,cliente.getCnh());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados atualizados");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados: "
					+e.getMessage());
		}
	}//fim alteraDados
	
	public void apagaRegistro(String cnh){
		String comandoSQL = "delete from cliente where cnh = ?";
		boolean check = existeCliente(cnh);
		if(check == true){
			try {
				PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
				stmt.setString(1, cnh);
				stmt.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro apagado");
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "N�o foi poss�vel apagar o registro: "
						+e.getMessage());
			}
		}else{
			JOptionPane.showMessageDialog(null,"O cliente n�o consta no banco");
		}
		
	}//fim apagaRegistro
	
	public void fechaBanco(){
		try {
			conexaoBD.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel fechar "
					+ "a conex�o com o banco");
		}
	}//fim fechaBanco
	
}
