package br.aulasjava.modelo;

public class Cliente {

	//Atributos
	private int idCliente;
	private String nome;
	private String cnh;
	private int anoValidadeCnh;
	
	//Getters & Setters
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCnh() {
		return cnh;
	}
	public void setCnh(String cnh) {
		this.cnh = cnh;
	}
	public int getAnoValidadeCnh() {
		return anoValidadeCnh;
	}
	public void setAnoValidadeCnh(int anoValidadeCnh) {
		this.anoValidadeCnh = anoValidadeCnh;
	}
}
