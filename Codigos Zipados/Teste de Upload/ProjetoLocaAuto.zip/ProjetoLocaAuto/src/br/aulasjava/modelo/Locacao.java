package br.aulasjava.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Locacao {

	//Atributos
	private int idLocacao;
	private Cliente cliente;
	private Veiculo veiculo;
	private Date dataLocacao;
	private Date dataDevolucao;
	private Date dataPrevisaoDevolucao;
	
	public int getIdLocacao() {
		return idLocacao;
	}
	public void setIdLocacao(int idLocacao) {
		this.idLocacao = idLocacao;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Veiculo getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
	public Date getDataLocacao() {
		return dataLocacao;
	}
	public void setDataLocacao(String dataLocacao) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Date data = null;
		try {
			data = df.parse(dataLocacao);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.dataLocacao = data;
	}
	
	public void setDataLocacao(java.sql.Date dataSQL){
		this.dataLocacao = dataSQL;
	}
	
	public Date getDataDevolucao() {
		return dataDevolucao;
	}
	public void setDataDevolucao(String dataDevolucao) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		Date data=null;
		try {
			data = df.parse(dataDevolucao);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.dataDevolucao = data;
	}
	public void setDataDevolucao(java.sql.Date dataSQL){
		this.dataDevolucao = dataSQL;
	}
	
	public Date getDataPrevisaoDevolucao() {
		return dataPrevisaoDevolucao;
	}
	public void setDataPrevisaoDevolucao(String dataPrevisaoDevolucao) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date data = null;
		try {
			data = df.parse(dataPrevisaoDevolucao);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.dataPrevisaoDevolucao = data;
	}
	
	public void setDataPrevisaoDevolucao(java.sql.Date dataSQL){
		this.dataPrevisaoDevolucao = dataSQL;
	}
}
