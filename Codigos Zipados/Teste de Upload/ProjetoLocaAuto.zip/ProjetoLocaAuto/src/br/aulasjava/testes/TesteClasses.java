package br.aulasjava.testes;

import br.aulasjava.modelo.Cliente;
import br.aulasjava.modelo.Locacao;
import br.aulasjava.modelo.Veiculo;

public class TesteClasses {

	public static void main(String[] args) {
		Cliente cliente1 = new Cliente();
		Veiculo veiculo1 = new Veiculo();
		
		cliente1.setIdCliente(1);
		cliente1.setNome("Carlos Eduardo");
		cliente1.setCnh("123456");
		cliente1.setAnoValidadeCnh(2020);
		
		veiculo1.setIdVeiculo(1);
		veiculo1.setPlaca("KOG7895");
		veiculo1.setModelo("Amarok");
		veiculo1.setAno(2015);
		
		Locacao locacao1 = new Locacao();
		locacao1.setIdLocacao(1);
		locacao1.setCliente(cliente1);
		locacao1.setVeiculo(veiculo1);
		locacao1.setDataLocacao("29/11/2016");
		locacao1.setDataPrevisaoDevolucao("05/12/2016");
		
		System.out.println("Loca��o n�: " +locacao1.getIdLocacao());
		System.out.println("Cliente: " +locacao1.getCliente().getNome());
		System.out.println("CNH Cliente: " +locacao1.getCliente().getCnh());
		System.out.println("Validade CNH: " +locacao1.getCliente().getAnoValidadeCnh());
		System.out.println("Placa do ve�culo: " +locacao1.getVeiculo().getPlaca());
		System.out.println("Modelo do ve�culo: " +locacao1.getVeiculo().getModelo());
		System.out.println("Data da loca��o: " +locacao1.getDataLocacao());
		System.out.println("Data prevista de devolu��o: " +locacao1.getDataPrevisaoDevolucao());
		
				
		
	}
}
