package br.aulasjava.testes;

import java.util.ArrayList;
import java.util.List;

import br.aulasjava.jdbc.dao.ClienteDao;
import br.aulasjava.modelo.Cliente;

public class TesteClienteDao {

	public static void main(String[] args) {
		Cliente cliente1 = new Cliente();
		Cliente cliente2 = new Cliente();
		Cliente cliente3 = new Cliente();
		ClienteDao clienteDao = new ClienteDao();
		
		/*Testando o adicionaBD
		
		cliente1.setNome("Maria");
		cliente1.setCnh("1234");
		cliente1.setAnoValidadeCnh(2019);
		
		cliente2.setNome("Pedro");
		cliente2.setCnh("5678");
		cliente2.setAnoValidadeCnh(2021);
		
		cliente3.setNome("Carla");
		cliente3.setCnh("9012");
		cliente3.setAnoValidadeCnh(2022);
		
		clienteDao.adicionaBD(cliente1);
		clienteDao.adicionaBD(cliente2);
		clienteDao.adicionaBD(cliente3);*/
		
		/*Testando buscaTodosClientes 
		List<Cliente> lista = new ArrayList<Cliente>();
		
		lista = clienteDao.buscaTodosClientes();
		for(int i=0;i<lista.size();i++){
			System.out.println("Nome: " +lista.get(i).getNome());
			System.out.println("CNH: " +lista.get(i).getCnh());
			System.out.println("Ano Validade: " +lista.get(i).getAnoValidadeCnh());
			System.out.println("---------------------------------------");
		}*/
		
		/*Testando buscaPorCnh
		cliente1 = clienteDao.buscaPorCnh("1234");
		System.out.println("Id: " +cliente1.getIdCliente());
		System.out.println("Nome: " +cliente1.getNome());
		System.out.println("CNH: " +cliente1.getCnh());
		System.out.println("Ano validade: " +cliente1.getAnoValidadeCnh());*/
		
		/*Testando buscaPorId
		cliente1 = clienteDao.buscaPorId(3);
		System.out.println("Id: " +cliente1.getIdCliente());
		System.out.println("Nome: " +cliente1.getNome());
		System.out.println("CNH: " +cliente1.getCnh());
		System.out.println("Ano validade: " +cliente1.getAnoValidadeCnh());*/
		
		/*cliente1.setNome("Maria Jos�");
		cliente1.setCnh("1234");
		cliente1.setAnoValidadeCnh(2025);
		
		clienteDao.alteraDados(cliente1);
		
		cliente1 = clienteDao.buscaPorCnh("1234");
		System.out.println("Id: " +cliente1.getIdCliente());
		System.out.println("Nome: " +cliente1.getNome());
		System.out.println("CNH: " +cliente1.getCnh());
		System.out.println("Ano validade: " +cliente1.getAnoValidadeCnh());*/
	
		clienteDao.apagaRegistro("5678");
		
		
		
		
	}
}
