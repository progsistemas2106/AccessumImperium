package br.aulasjava.testes;

import br.aulasjava.jdbc.dao.VeiculoDao;
import br.aulasjava.modelo.Veiculo;

public class TesteVeiculoDao {
	
	public static void main(String[] args) {
		Veiculo veiculo1 = new Veiculo();
		Veiculo veiculo2 = new Veiculo();
		VeiculoDao veiculoDao = new VeiculoDao();
		
		veiculo1.setPlaca("KOG7894");
		veiculo1.setModelo("Ford Ka");
		veiculo1.setAno(2014);
		
		veiculo2.setPlaca("LOP1256");
		veiculo2.setModelo("HB20");
		veiculo2.setAno(2016);
		
		veiculoDao.adicionaBD(veiculo1);
		veiculoDao.adicionaBD(veiculo2);
	}
}
