package br.aulasjava.testes;

import java.util.List;

import br.aulasjava.jdbc.dao.ClienteDao;
import br.aulasjava.jdbc.dao.LocacaoDao;
import br.aulasjava.jdbc.dao.VeiculoDao;
import br.aulasjava.modelo.Cliente;
import br.aulasjava.modelo.Locacao;
import br.aulasjava.modelo.Veiculo;

public class TesteLocacao {

	public static void main(String[] args) {
		Cliente cliente1 = new Cliente();
		Veiculo veiculo1 = new Veiculo();
		Locacao locacao1 = new Locacao();
		ClienteDao clienteDao = new ClienteDao();
		VeiculoDao veiculoDao = new VeiculoDao();
		LocacaoDao locacaoDao = new LocacaoDao();
		
		/*cliente1 = clienteDao.buscaPorCnh("456123");
		veiculo1 = veiculoDao.buscaPorPlaca("KKK1593");
		
		
		locacao1.setCliente(cliente1);
		locacao1.setVeiculo(veiculo1);
		locacao1.setDataLocacao("08/12/2016");
		locacao1.setDataPrevisaoDevolucao("15/12/2016");
		locacaoDao.adicionaBD(locacao1);
*/
		
		
		List<Locacao> lista = new LocacaoDao().buscaTodasLocacoes();
		String saida = "";
		for(int i=0;i<lista.size();i++){
			saida = saida +"\n"
					+lista.get(i).getIdLocacao() +"\n"
					+lista.get(i).getCliente().getNome() +"\n"
					+lista.get(i).getVeiculo().getModelo() +"\n"
					+lista.get(i).getVeiculo().getPlaca() +"\n"
					+lista.get(i).getDataLocacao() +"\n"
					+lista.get(i).getDataPrevisaoDevolucao() +"\n";
		}
		System.out.println(saida);
	}
}
