create database locaauto;

use locaauto;

create table cliente(
idCliente int auto_increment,
nome varchar(100) not null,
cnh varchar(14) unique not null,
anoValidadeCNH int not null,
primary key(idCliente));

create table veiculo(
idVeiculo int auto_increment,
placa varchar (8) unique not null,
modelo varchar(30),
ano int,
primary key(idVeiculo));

create table locacao(
idLocacao int auto_increment,
idVeiculo int not null,
idCliente int not null,
dataLocacao date,
dataDevolucao date,
dataPrevisaoDevolucao date,
foreign key (idCliente) references cliente (idCliente),
foreign key (idVeiculo) references veiculo (idVeiculo),
primary key(idLocacao));