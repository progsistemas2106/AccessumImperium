
package br.accessumimperium.testes;

import br.accessumimperium.jdbc.dao.EventoDao;
import br.accessumimperium.jdbc.dao.IngressoDao;
import br.accessumimperium.modelo.Evento;
import br.accessumimperium.modelo.Ingresso;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Alessandra
 */
public class TesteIngressoDao {
    
    public static void main(String[] args) {
		Ingresso ingresso1 = new Ingresso();
		Ingresso ingresso2 = new Ingresso();
		IngressoDao ingressoDao = new IngressoDao();
        Evento evento1 = new Evento();
        Evento evento2 = new Evento();
        EventoDao eventoDao = new EventoDao();
                
        evento1 = eventoDao.buscaPorId(1);
        evento2 = eventoDao.buscaPorId(2);
		
		/*ingresso1.setCodigo("123aa45ff");
		ingresso1.setValor(80.00);
		ingresso1.setCategoria("...");
        ingresso1.setLote(1);
        ingresso1.setEvento(evento1);
        ingresso1.setStatusIngresso("V�lido");
                
		ingressoDao.adicionaBD(ingresso1);*/
		
		/*ingresso2.setCodigo("78r5k321");
		ingresso2.setValor(100.00);
		ingresso2.setCategoria("...");
		ingresso2.setLote(1);
		ingresso2.setEvento(evento2);
		ingresso2.setStatusIngresso("V�lido");
                
		ingressoDao.adicionaBD(ingresso2);*/
		
		
        /*//Testando buscaTodasCasasDeEventos 
		List<Ingresso> lista = new ArrayList<Ingresso>();
		
		lista = ingressoDao.buscaTodosIngressos();
		for(int i=0;i<lista.size();i++){
			System.out.println("C�digo: " +lista.get(i).getCodigo());
			System.out.println("Valor: " +lista.get(i).getValor());
			System.out.println("Categoria: " +lista.get(i).getCategoria());
            System.out.println("Lote: "+lista.get(i).getLote());
            System.out.println("Evento: "+lista.get(i).getEvento().getNome());
			System.out.println("---------------------------------------");
		}*/
		
		//Testando buscaPorCodigo
               
		/*ingresso1 = ingressoDao.buscaPorCodigo("123aa45ff");
                
               
		System.out.println("C�digo: " +ingresso1.getCodigo());
		System.out.println("Valor: " +ingresso1.getValor());
		System.out.println("Categoria: " +ingresso1.getCategoria());
        System.out.println("Lote: "+ingresso1.getLote());
        System.out.println("Evento: "+ingresso1.getEvento().getNome());
	    System.out.println("---------------------------------------");*/
		
	    //Testando alteraDados
        evento1 = eventoDao.buscaPorId(1);
                
		ingresso1.setCodigo("78r5k321");
		ingresso1.setValor(200.00);
		ingresso1.setCategoria("...");
        ingresso1.setLote(2);
        ingresso1.setStatusIngresso("Cancelado");
        ingresso1.setEvento(evento1);

		ingressoDao.alteraDados(ingresso1);
		
	}
}
