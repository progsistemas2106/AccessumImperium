package br.accessumimperium.testes;

import java.util.ArrayList;
import java.util.List;

import br.accessumimperium.jdbc.dao.CasaDeEventosDao;
import br.accessumimperium.modelo.CasaDeEventos;

public class TesteCasaDeEventosDao {

	public static void main(String[] args) {
		CasaDeEventos casaDeEventos1 = new CasaDeEventos();
		CasaDeEventos casaDeEventos2 = new CasaDeEventos();
		CasaDeEventosDao casaDeEventosDao = new CasaDeEventosDao();
		
		casaDeEventos1.setCnpj("1234");
		casaDeEventos1.setNome("Evento tal");
		casaDeEventos1.setEndereco("Rua...");
		
		casaDeEventos2.setCnpj("12345");
		casaDeEventos2.setNome("Outro Evento");
		casaDeEventos2.setEndereco("Av...");
		
		casaDeEventosDao.adicionaBD(casaDeEventos1);
		casaDeEventosDao.adicionaBD(casaDeEventos2);
		
		//Testando buscaTodasCasasDeEventos 
		List<CasaDeEventos> lista = new ArrayList<CasaDeEventos>();
		
		lista = casaDeEventosDao.buscaTodasCasasDeEventos();
		for(int i=0;i<lista.size();i++){
			System.out.println("Nome: " +lista.get(i).getNome());
			System.out.println("CNPJ: " +lista.get(i).getCnpj());
			System.out.println("Endere�o: " +lista.get(i).getEndereco());
			System.out.println("---------------------------------------");
		}
		
		//Testando buscaPorCnpj
		casaDeEventos1 = casaDeEventosDao.buscaPorCnpj("1234");
		System.out.println("Nome: " +casaDeEventos1.getNome());
		System.out.println("CNPJ: " +casaDeEventos1.getCnpj());
		System.out.println("Endere�o: " +casaDeEventos1.getEndereco());
		
		
		casaDeEventos1.setNome("Outro Nome");
		casaDeEventos1.setCnpj("12345");
		casaDeEventos1.setEndereco("Rua,...");
		
		casaDeEventosDao.alteraDados(casaDeEventos1);
		
		
		//casaDeEventosDao.apagaRegistro("1a2b3c");
		
	}
}