package br.accessumimperium.testes;

import java.util.ArrayList;
import java.util.List;

import br.accessumimperium.jdbc.dao.CasaDeEventosDao;
import br.accessumimperium.jdbc.dao.EventoDao;
import br.accessumimperium.modelo.CasaDeEventos;
import br.accessumimperium.modelo.Evento;

public class TesteEventoDao {

	public static void main(String[] args) {
		Evento evento1 = new Evento();
		Evento evento2 = new Evento();
                Evento evento3 = new Evento();
		EventoDao eventoDao = new EventoDao();
		CasaDeEventosDao casaDeEventosDao = new CasaDeEventosDao();
		CasaDeEventos casaDeEventos1 = new CasaDeEventos();
                CasaDeEventos casaDeEventos2 = new CasaDeEventos();
		
		casaDeEventos1 = casaDeEventosDao.buscaPorCnpj("1234");
		
		evento1.setNome("...");
		evento1.setDataInicio("10/01/2017");
		evento1.setDataFim("10/03/2017");
		evento1.setCabecalho("...");
		evento1.setQtdeMaxIngresso(1000);
		evento1.setStatusEvento("Ativo");
		evento1.setIngresso("...");
		evento1.setCasaDeEventos(casaDeEventos1);
		
		casaDeEventos2 = casaDeEventosDao.buscaPorCnpj("12345");
                
		
		/*evento2.setNome("Outro");
		evento2.setDataInicio("05/05/2017");
		evento2.setDataFim("05/06/2017");
		evento2.setCabecalho("...");
		evento2.setQtdeMaxIngresso(2000);
		evento2.setStatusEvento("Ativo");
		evento2.setIngresso("...");
		evento2.setCasaDeEventos(casaDeEventos1);
		
                evento3.setNome("Evento...");
		evento3.setDataInicio("07/05/2017");
		evento3.setDataFim("07/06/2017");
		evento3.setCabecalho("...");
		evento3.setQtdeMaxIngresso(3000);
		evento3.setStatusEvento("Ativo");
		evento3.setIngresso("...");
		evento3.setCasaDeEventos(casaDeEventos1);
		
		
		eventoDao.adicionaBD(evento1);
		eventoDao.adicionaBD(evento2);
        eventoDao.adicionaBD(evento3);
		
		//Testando buscaTodosEventos 
		List<Evento> lista = new ArrayList<Evento>();
		
		lista = eventoDao.buscaTodosEventos();
		for(int i=0;i<lista.size();i++){
			System.out.println("Nome: " +lista.get(i).getNome());
			System.out.println("Data: " +lista.get(i).getDataInicio()+"At� "+lista.get(i).getDataFim());
			System.out.println("Cabe�alho: " +lista.get(i).getCabecalho());
			System.out.println("Quantidade m�xima de ingressos: " +lista.get(i).getQtdeMaxIngresso());
			System.out.println("Ingresso: " +lista.get(i).getIngresso());
			System.out.println("Status: " +lista.get(i).getStatusEvento());
			System.out.println("Local: " +lista.get(i).getCasaDeEventos().getNome()+"\n"+
			lista.get(i).getCasaDeEventos().getEndereco());
			System.out.println("---------------------------------------");
		}
		
		//Testando buscaPorId
		evento1 = eventoDao.buscaPorId(1);
		System.out.println("Nome: " +evento1.getNome());
		System.out.println("Data: " +evento1.getDataInicio()+"\n"+evento1.getDataFim());
		System.out.println("Cabe�alho: " +evento1.getCabecalho());
		System.out.println("Quantidade m�xima de ingressos: " +evento1.getQtdeMaxIngresso());
		System.out.println("StatusEvento: " +evento1.getStatusEvento());
		System.out.println("Ingresso: " +evento1.getIngresso());
		System.out.println("Casa De Eventos: " +evento1.getCasaDeEventos().getCnpj());
*/		
        //Testa alteraDados
		casaDeEventos1 = casaDeEventosDao.buscaPorCnpj("1234");
		
		evento2.setIdEvento(1);
		evento2.setNome("Qualquer");
		evento2.setDataInicio("05/05/2017");
		evento2.setDataFim("05/06/2017");
		evento2.setCabecalho("...");
		evento2.setQtdeMaxIngresso(3000);
		evento2.setStatusEvento("Ativo");
		evento2.setIngresso("...");
		evento2.setCasaDeEventos(casaDeEventos1);
		
		eventoDao.alteraDados(evento2);
		
	}
}
