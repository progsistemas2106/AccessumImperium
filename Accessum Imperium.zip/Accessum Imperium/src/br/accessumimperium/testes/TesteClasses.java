/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.accessumimperium.testes;

import br.accessumimperium.modelo.CasaDeEventos;
import br.accessumimperium.modelo.Evento;
import br.accessumimperium.modelo.Ingresso;

/**
 *
 * @author Alessandra
 */
public class TesteClasses {
    public static void main(String[] args) {
		Evento evento1 = new Evento();
		CasaDeEventos casaDeEventos1 = new CasaDeEventos();
		
		
		evento1.setNome("Evento...");
		evento1.setDataInicio("12/01/2017");
		evento1.setDataFim("12/02/2017");
                evento1.setCabecalho("...");
                evento1.setQtdeMaxIngresso(2000);
                evento1.setStatusEvento("Ativo");
                evento1.setIngresso("...");
                evento1.setCasaDeEventos(casaDeEventos1);
		
		casaDeEventos1.setCnpj("123456");
		casaDeEventos1.setNome("Nome...");
		casaDeEventos1.setEndereco("R.Tal,...");
		
		
		Ingresso ingresso1 = new Ingresso();
		ingresso1.setCodigo("3k22ft98");
		ingresso1.setValor(100.00);
		ingresso1.setCategoria("...");
		ingresso1.setLote(1);
		ingresso1.setEvento(evento1);
                ingresso1.setStatusIngresso("V�lido");
		
		System.out.println("Nome do Evento: " +evento1.getNome());
		System.out.println("Data: " +evento1.getDataInicio()+" - "+evento1.getDataFim());
		System.out.println("Cabe�alho: " +evento1.getCabecalho());
		System.out.println("Quantidade m�xima de ingressos: " +evento1.getQtdeMaxIngresso());
		System.out.println("Status do evento: " +evento1.getStatusEvento());
		System.out.println("Ingresso: " +evento1.getIngresso());
		System.out.println("Local: " +evento1.getCasaDeEventos().getNome());
		System.out.println("-------------------------------------------------------------------");
                System.out.println("Casa de Evento: "+casaDeEventos1.getNome());
                System.out.println("CNPJ: "+casaDeEventos1.getCnpj());
                System.out.println("Endere�o: "+casaDeEventos1.getEndereco());
                System.out.println("-------------------------------------------------------------------");
                System.out.println("C�digo do ingresso: "+ingresso1.getCodigo());
                System.out.println("Valor: "+ingresso1.getValor());
                System.out.println("Categoria: "+ingresso1.getCategoria());
                System.out.println("Lote: "+ingresso1.getLote());
                System.out.println("Evento: "+ingresso1.getEvento().getNome());
                System.out.println("Status do ingresso: "+ingresso1.getStatusIngresso());
		
				
		
	}
}
