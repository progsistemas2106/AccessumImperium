package br.accessumimperium.testes;

import java.sql.Connection;

import br.accessumimperium.jdbc.FabricaConexao;



public class TesteConexao {

	public static void main(String[] args) {
		Connection novaConexao = new FabricaConexao().conexao();
	}
}
