package br.accessumimperium.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Evento {

	private int idEvento;
	private String nome;
	private Date dataInicio;
	private Date dataFim;
	private String cabecalho;
	private int qtdeMaxIngresso;
	private String statusEvento;
	private String ingresso;
	private CasaDeEventos casaDeEventos;	
	
	
	public int getIdEvento() {
		return idEvento;
	}
	public void setIdEvento(int idEvento) {
		this.idEvento = idEvento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getDataInicio() {
		return dataInicio;
	}
	
	public void setDataInicio(String dataInicio) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Date data = null;
		try {
			data = df.parse(dataInicio);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.dataInicio = data;
	}
	
	public void setDataInicio(java.sql.Date dataSQL){
		this.dataInicio = dataSQL;
	}
	public Date getDataFim() {
		return dataFim;
	}
	public void setDataFim(String dataFim) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Date data = null;
		try {
			data = df.parse(dataFim);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.dataFim = data;
	}
	
	public void setDataFim(java.sql.Date dataSQL){
		this.dataFim = dataSQL;
	}
	public String getCabecalho() {
		return cabecalho;
	}
	public void setCabecalho(String cabecalho) {
		this.cabecalho = cabecalho;
	}
	public int getQtdeMaxIngresso() {
		return qtdeMaxIngresso;
	}
	public void setQtdeMaxIngresso(int qtdeMaxIngresso) {
		this.qtdeMaxIngresso = qtdeMaxIngresso;
	}
	public String getStatusEvento() {
		return statusEvento;
	}
	public void setStatusEvento(String statusEvento) {
		this.statusEvento = statusEvento;
	}
	public CasaDeEventos getCasaDeEventos() {
		return casaDeEventos;
	}
	public void setCasaDeEventos(CasaDeEventos casaDeEventos) {
		this.casaDeEventos = casaDeEventos;
	}
	public String getIngresso() {
		return ingresso;
	}
	public void setIngresso(String ingresso) {
		this.ingresso = ingresso;
	}
	
	
	
}
