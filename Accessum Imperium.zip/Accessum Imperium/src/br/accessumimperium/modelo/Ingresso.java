/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.accessumimperium.modelo;

/**
 *
 * @author Alessandra
 */
public class Ingresso {
   
    private String codigo;
    private double valor;
    private String categoria;
    private int lote;
    private Evento evento;
    private String statusIngresso;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getLote() {
        return lote;
    }

    public void setLote(int lote) {
        this.lote = lote;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public String getStatusIngresso() {
        return statusIngresso;
    }

    public void setStatusIngresso(String statusIngresso) {
        this.statusIngresso = statusIngresso;
    }
    
    
}
