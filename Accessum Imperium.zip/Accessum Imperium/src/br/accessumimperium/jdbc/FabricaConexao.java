package br.accessumimperium.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class FabricaConexao {

	public Connection conexao(){
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/eventobd?autoReconnect=false&useSSL=false","root","root");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao conectar no banco de dados: " +e.getMessage());
			return null;
		}		
	}
}
