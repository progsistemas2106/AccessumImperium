/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.accessumimperium.jdbc.dao;

import br.accessumimperium.jdbc.FabricaConexao;
import br.accessumimperium.modelo.Evento;
import br.accessumimperium.modelo.Ingresso;
import br.accessumimperium.modelo.Ingresso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Alessandra
 */
public class IngressoDao {
    
    private Connection conexaoBD;
    
    public IngressoDao() {
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do construtor
	
	public void adicionaBD(Ingresso ingresso){
		String commandoSQL = "insert into ingresso (codigo, valor, categoria, lote, idEvento, statusIngresso)"
				+ "values (?,?,?,?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(commandoSQL);
			stmt.setString(1, ingresso.getCodigo());
			stmt.setDouble(2, ingresso.getValor());
			stmt.setString(3, ingresso.getCategoria());
                        stmt.setInt(4, ingresso.getLote());
                        stmt.setInt(5, ingresso.getEvento().getIdEvento());
                        stmt.setString(6, ingresso.getStatusIngresso());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso.");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco: "+e.getMessage());
		}
	}//Fim do m�todo adicionaBD
	
	public List<Ingresso> buscaTodosIngressos(){
		
		String comandoSQL = "select * from ingresso";
		try {
			List<Ingresso> ingressoLista = new ArrayList<Ingresso>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Ingresso ingresso  = new Ingresso();
                                Evento evento = new Evento();
                                EventoDao eventoDao = new EventoDao();
                                
				ingresso.setCodigo(rs.getString("codigo"));
				ingresso.setValor(rs.getDouble("valor"));
				ingresso.setCategoria(rs.getString("categoria"));
                                ingresso.setLote(rs.getInt("lote"));
                                evento = eventoDao.buscaPorId(rs.getInt("idEvento"));
				ingresso.setEvento(evento);
                                ingresso.setStatusIngresso(rs.getString("statusIngresso"));
			
				ingressoLista.add(ingresso);
			}
			rs.close();
			stmt.close();
			return ingressoLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados do Banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
		
	}//Fim do m�todo buscaTodosIngresso
	
	public Ingresso buscaPorCodigo(String codigo){
		String comandoSQL = "select * from ingresso where codigo = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, codigo);
			ResultSet rs = stmt.executeQuery();
			
                        Ingresso ingresso = new Ingresso();
                        Evento evento = new Evento();
                        EventoDao eventoDao = new EventoDao();
                        
			if(rs.first()==true){
				ingresso.setCodigo(rs.getString("codigo"));
				ingresso.setValor(rs.getDouble("valor"));
				ingresso.setCategoria(rs.getString("categoria"));
                                ingresso.setLote(rs.getInt("lote"));
                                evento = eventoDao.buscaPorId(rs.getInt("idEvento"));
				ingresso.setEvento(evento);
                                ingresso.setStatusIngresso(rs.getString("statusIngresso"));
                                
                                
				
			}else{
				JOptionPane.showMessageDialog(null, "Ingresso n�o encontrado");
			}
			rs.close();
			stmt.close();
			return ingresso;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	public void alteraDados(Ingresso ingresso){
		String comandoSQL = "update ingresso set valor = ?, categoria = ?,lote = ?, idEvento = ?, statusIngresso = ? where codigo = ? ";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setDouble(1, ingresso.getValor());
			stmt.setString(2, ingresso.getCategoria());
                        stmt.setInt(3, ingresso.getLote());
                        stmt.setInt(4, ingresso.getEvento().getIdEvento());
                        stmt.setString(5, ingresso.getStatusIngresso());
                        stmt.setString(6, ingresso.getCodigo());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados atualizados");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados: "
					+e.getMessage());
		}
	}//fim alteraDados
	
	
	
	public void fechaBanco(){
		try {
			conexaoBD.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel fechar "
					+ "a conex�o com o banco");
		}
	}//fim fechaBanco
	
}
