package br.accessumimperium.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.accessumimperium.jdbc.FabricaConexao;
import br.accessumimperium.modelo.CasaDeEventos;
import br.accessumimperium.modelo.Evento;

public class EventoDao {

private Connection conexaoBD;
	
	public EventoDao() {
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do construtor
	
	public void adicionaBD(Evento evento){
		String commandoSQL = "insert into evento (nome, dataInicio, dataFim, cabecalho, qtdeMaxIngresso, statusEvento, ingresso, cnpj)"
				+ "values (?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(commandoSQL);
			stmt.setString(1, evento.getNome());
			java.sql.Date dataInicioSQL = new java.sql.Date(evento.getDataInicio().getTime());
			java.sql.Date dataFimSQL = new java.sql.Date(evento.getDataFim().getTime());
			stmt.setDate(2, dataInicioSQL);
			stmt.setDate(3, dataFimSQL);
			stmt.setString(4, evento.getCabecalho());
			stmt.setInt(5, evento.getQtdeMaxIngresso());
			stmt.setString(6, evento.getStatusEvento());
			stmt.setString(7, evento.getIngresso());
			stmt.setString(8, evento.getCasaDeEventos().getCnpj());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso.");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco: "+e.getMessage());
		}
	}//Fim do m�todo adicionaBD
	
	public List<Evento> buscaTodosEventos(){
		
		String comandoSQL = "select * from evento";
		try {
			List<Evento> eventoLista = new ArrayList<Evento>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Evento evento  = new Evento();
				CasaDeEventos casaDeEventos = new CasaDeEventos();	
				CasaDeEventosDao casaDeEventosDao = new CasaDeEventosDao();
				
				evento.setIdEvento(rs.getInt("idEvento"));
				casaDeEventos = casaDeEventosDao.buscaPorCnpj(rs.getString("cnpj"));
				evento.setCasaDeEventos(casaDeEventos);
				evento.setNome(rs.getString("nome"));
				evento.setDataInicio(rs.getDate("dataInicio"));
				evento.setDataFim(rs.getDate("dataFim"));
				evento.setCabecalho(rs.getString("cabecalho"));
				evento.setQtdeMaxIngresso(rs.getInt("qtdeMaxIngresso"));
				evento.setStatusEvento(rs.getString("statusEvento"));
				evento.setIngresso(rs.getString("ingresso"));
				
			
				eventoLista.add(evento);
			}
			rs.close();
			stmt.close();
			return eventoLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados do Banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
		
	}//Fim do m�todo buscaTodosEventos
	
	public Evento buscaPorId(int idEvento){
		String comandoSQL = "select * from evento where idEvento = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setInt(1, idEvento);
			ResultSet rs = stmt.executeQuery();
			
			Evento evento = new Evento();
			CasaDeEventos casaDeEventos = new CasaDeEventos();
			CasaDeEventosDao casaDeEventosDao = new CasaDeEventosDao();
			
			if(rs.first()==true){
				evento.setIdEvento(rs.getInt("idEvento"));
				casaDeEventos = casaDeEventosDao.buscaPorCnpj(rs.getString("cnpj"));
				evento.setCasaDeEventos(casaDeEventos);
				evento.setNome(rs.getString("nome"));
				evento.setDataInicio(rs.getDate("dataInicio"));
				evento.setDataFim(rs.getDate("dataFim"));
				evento.setCabecalho(rs.getString("cabecalho"));
				evento.setQtdeMaxIngresso(rs.getInt("qtdeMaxIngresso"));
				evento.setStatusEvento(rs.getString("statusEvento"));
				evento.setIngresso(rs.getString("ingresso"));
				
			}else{
				JOptionPane.showMessageDialog(null, "Evento n�o encontrado");
			}
			rs.close();
			stmt.close();
			return evento;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo buscaPorId
	
	public void alteraDados(Evento evento){
		String comandoSQL = "update evento set nome = ?, dataInicio = ?, dataFim = ?, cabecalho = ?, qtdeMaxIngresso = ?,"
				+ "statusEvento = ?, ingresso = ?, cnpj = ? where idEvento = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, evento.getNome());
			java.sql.Date dataInicioSQL = new java.sql.Date(evento.getDataInicio().getTime());
			java.sql.Date dataFimSQL = new java.sql.Date(evento.getDataFim().getTime());
			stmt.setDate(2, dataInicioSQL);
			stmt.setDate(3, dataFimSQL);
			stmt.setString(4, evento.getCabecalho());
			stmt.setInt(5, evento.getQtdeMaxIngresso());
			stmt.setString(6, evento.getStatusEvento());
			stmt.setString(7, evento.getIngresso());
			stmt.setString(8, evento.getCasaDeEventos().getCnpj());
                        stmt.setInt(9, evento.getIdEvento());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados atualizados");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados: "
					+e.getMessage());
		}
	}//fim alteraDados
	
	public void fechaBanco(){
		try {
			conexaoBD.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel fechar "
					+ "a conex�o com o banco");
		}
	}//fim fechaBanco
	
}
