package br.accessumimperium.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.accessumimperium.jdbc.FabricaConexao;
import br.accessumimperium.modelo.CasaDeEventos;



public class CasaDeEventosDao {

private Connection conexaoBD;
	
	public CasaDeEventosDao() {
		conexaoBD = new FabricaConexao().conexao();
	}//Fim do construtor
	
	public void adicionaBD(CasaDeEventos casaDeEventos){
		String commandoSQL = "insert into casaDeEventos (cnpj, nome, endereco)"
				+ "values (?,?,?)";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(commandoSQL);
			stmt.setString(1, casaDeEventos.getCnpj());
			stmt.setString(2, casaDeEventos.getNome());
			stmt.setString(3, casaDeEventos.getEndereco());
			
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso.");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco: "+e.getMessage());
		}
	}//Fim do m�todo adicionaBD
	
	public List<CasaDeEventos> buscaTodasCasasDeEventos(){
		
		String comandoSQL = "select * from casaDeEventos";
		try {
			List<CasaDeEventos> casaDeEventosLista = new ArrayList<CasaDeEventos>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				CasaDeEventos casaDeEventos  = new CasaDeEventos();
				casaDeEventos.setCnpj(rs.getString("cnpj"));
				casaDeEventos.setNome(rs.getString("nome"));
				casaDeEventos.setEndereco(rs.getString("endereco"));
			
				casaDeEventosLista.add(casaDeEventos);
			}
			rs.close();
			stmt.close();
			return casaDeEventosLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados do Banco: "
					+e.getMessage());
			return Collections.emptyList();
		}
		
	}//Fim do m�todo buscaTodosCasaDeEventos
	
	public CasaDeEventos buscaPorCnpj(String cnpj){
		String comandoSQL = "select * from casaDeEventos where cnpj = ?";
		
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, cnpj);
			ResultSet rs = stmt.executeQuery();
			CasaDeEventos casaDeEventos = new CasaDeEventos();
			if(rs.first()==true){
				casaDeEventos.setCnpj(rs.getString("cnpj"));
				casaDeEventos.setNome(rs.getString("nome"));
				casaDeEventos.setEndereco(rs.getString("endereco"));
				
			}else{
				JOptionPane.showMessageDialog(null, "Casa de Eventos n�o encontrada");
			}
			rs.close();
			stmt.close();
			return casaDeEventos;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a busca: "
					+e.getMessage());
			return null;
		}
	}//Fim do m�todo
	
	
	
	
	public boolean existeCasaDeEventos(String cnpj){
		String comandoSQL = "select * from casaDeEventos where cnpj = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, cnpj);
			ResultSet rs = stmt.executeQuery();
			if(rs.first()==true){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao realizar a verifica��o: "
					+e.getMessage());
			return false;
		}
	}
	
	public void alteraDados(CasaDeEventos casaDeEventos){
		String comandoSQL = "update casaDeEventos set nome = ?, endereco = ? where cnpj = ?";
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, casaDeEventos.getNome());
			stmt.setString(2, casaDeEventos.getEndereco());
			stmt.setString(3,casaDeEventos.getCnpj());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados atualizados");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados: "
					+e.getMessage());
		}
	}//fim alteraDados
	
	public void apagaRegistro(String cnpj){
		String comandoSQL = "delete from casaDeEventos where cnpj = ?";
		boolean check = existeCasaDeEventos(cnpj);
		if(check == true){
			try {
				PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
				stmt.setString(1, cnpj);
				stmt.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro apagado");
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "N�o foi poss�vel apagar o registro: "
						+e.getMessage());
			}
		}else{
			JOptionPane.showMessageDialog(null,"A casa de eventos n�o consta no banco");
		}
		
	}//fim apagaRegistro
	
	public void fechaBanco(){
		try {
			conexaoBD.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel fechar "
					+ "a conex�o com o banco");
		}
	}//fim fechaBanco
	
}
